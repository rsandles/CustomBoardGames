import bpy

def add_dummy():
    
    sc =  bpy.data.scenes["Scene"]
    
    myactive =  bpy.context.active_object
    
    name = "dummy"
    
    
    verts = [
            ( -19.4641170501709 , -19.4641170501709 , -24.586917877197266 ) ,
            ( -13.072190284729004 , -13.072190284729004 , 20.705020904541016 ) ,
            ( -19.4641170501709 , 19.4641170501709 , -24.586917877197266 ) ,
            ( -13.072190284729004 , 13.072190284729004 , 20.705020904541016 ) ,
            ( 19.4641170501709 , -19.4641170501709 , -24.586917877197266 ) ,
            ( 13.072190284729004 , -13.072190284729004 , 20.705020904541016 ) ,
            ( 19.4641170501709 , 19.4641170501709 , -24.586917877197266 ) ,
            ( 13.072190284729004 , 13.072190284729004 , 20.705020904541016 ) ,
            ( -1.1055102348327637 , -1.1055102348327637 , 11.542899131774902 ) ,
            ( -1.1055102348327637 , 1.1055102348327637 , 11.542899131774902 ) ,
            ( 1.1055102348327637 , 1.1055102348327637 , 11.542899131774902 ) ,
            ( 1.1055102348327637 , -1.1055102348327637 , 11.542899131774902 ) ,
            ( -18.865652084350586 , 18.865652084350586 , -23.15060043334961 ) ,
            ( 18.865652084350586 , 18.865652084350586 , -23.15060043334961 ) ,
            ( 18.865652084350586 , -18.865652084350586 , -23.15060043334961 ) ,
            ( -18.865652084350586 , -18.865652084350586 , -23.15060043334961 ) ,
            ( -4.309758186340332 , -4.309758186340332 , 29.695510864257812 ) ,
            ( -4.309758186340332 , 4.309758186340332 , 29.695510864257812 ) ,
            ( 4.309758186340332 , 4.309758186340332 , 29.695510864257812 ) ,
            ( 4.309758186340332 , -4.309758186340332 , 29.695510864257812 )
            ]
  
    faces = [
            ( 8 , 1 , 3 , 9 ) ,
            ( 9 , 3 , 7 , 10 ) ,
            ( 10 , 7 , 5 , 11 ) ,
            ( 11 , 5 , 1 , 8 ) ,
            ( 2 , 6 , 4 , 0 ) ,
            ( 1 , 5 , 19 , 16 ) ,
            ( 14 , 11 , 8 , 15 ) ,
            ( 13 , 10 , 11 , 14 ) ,
            ( 12 , 9 , 10 , 13 ) ,
            ( 15 , 8 , 9 , 12 ) ,
            ( 0 , 15 , 12 , 2 ) ,
            ( 2 , 12 , 13 , 6 ) ,
            ( 6 , 13 , 14 , 4 ) ,
            ( 4 , 14 , 15 , 0 ) ,
            ( 18 , 17 , 16 , 19 ) ,
            ( 7 , 3 , 17 , 18 ) ,
            ( 5 , 7 , 18 , 19 ) ,
            ( 3 , 1 , 16 , 17 )
            ]
    
    
    # Create the mesh and add the object to the scene
    
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts,[],faces)
    
    obj = bpy.data.objects.new(name,mesh)
    bpy.context.scene.objects.link(obj)
    
    bpy.context.scene.objects.active = obj
    obj.select = True
    myactive.select = False
    
    # Set scale
    obj.dimensions[0] = sc.dummy_width
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.dimensions[1] = sc.dummy_width
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.dimensions[2] = sc.dummy_height
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    
    # Set the dummy's location
    obj.location = myactive.location
    obj.location[2] = obj.dimensions[2]/2
    
    # Add a subsurf modifier
    sub = obj.modifiers.new(name="SUB",type="SUBSURF")
    sub.levels = 2
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.faces_shade_smooth()
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # Set all cycles property
    obj.cycles_visibility.camera = True
    obj.cycles_visibility.diffuse = False
    obj.cycles_visibility.glossy = False
    obj.cycles_visibility.transmission = False
    obj.cycles_visibility.scatter = False
    obj.cycles_visibility.shadow = False
    

    
class AddDummy(bpy.types.Operator):
    bl_idname = "my_operator.add_dummy"
    bl_label = "Add Dummy"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        add_dummy()
        return {"FINISHED"}
        