import bpy

def add_door():
    
    myactive = bpy.context.active_object
    
    sc = bpy.data.scenes["Scene"]
    
    # Add a cube and substract it from the selection
    bpy.ops.mesh.primitive_cube_add(radius=(sc.cell_size/4), view_align=False, enter_editmode=False, location=bpy.context.scene.cursor_location)
    door = bpy.context.active_object
    
    bpy.context.scene.objects.active = myactive
    
    opening = myactive.modifiers.new(name='DOOR',type='BOOLEAN')
    opening.object = door
    opening.operation = 'DIFFERENCE'
    bpy.ops.object.modifier_apply(modifier = 'DOOR')
    
    bpy.ops.object.delete()
    bpy.context.scene.objects.active = myactive
    myactive.select = True
    
    
    
class AddDoor(bpy.types.Operator):
    bl_idname = "my_operator.add_door"
    bl_label = "Add Door"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "Room" in obj.name    

    def execute(self, context):
        add_door()
        return {"FINISHED"}
        