'''
Copyright (C) 2019 Raphael SANDLES
rsandles@gmail.com

Created by Raphael SANDLES

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
    "name": "CBG Board",
    "description": "An addon to design boards for board games in Blender",
    "author": "Raphael SANDLES",
    "version": (0, 0, 3),
    "blender": (2, 79, 0),
    "location": "View3D",
    "warning": "This addon is still in development.",
    "wiki_url": "",
    "category": "Object" }


import bpy


# load and reload submodules
##################################

import importlib
from . import developer_utils
importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(__path__, __name__, "bpy" in locals())



# register
##################################

import traceback

import os

preview_collections = {}

def enum_previews_from_directory_items(self, context):
    """EnumProperty callback"""
    enum_items = []
    params = ["normal", "roughness", "heightmap", "AO"]

    if context is None:
        return enum_items

    wm = context.window_manager
    directory = wm.my_previews_dir

    # Get the preview collection (defined in register func).
    pcoll = preview_collections["main"]

    if directory == pcoll.my_previews_dir:
        return pcoll.my_previews

    print("Scanning directory: %s" % directory)

    if directory and os.path.exists(directory):
        # Scan the directory for png, jpg, tif files and not "roughness_", "normal_"...
        image_paths = []
        for fn in os.listdir(directory):
            #if fn.lower().endswith(".png"):
            if (fn.lower().endswith(".png") or fn.lower().endswith(".jpg") or fn.lower().endswith(".tiff")or fn.lower().endswith(".tif")) and not any(x in fn for x in params) :
                image_paths.append(fn)

        for i, name in enumerate(image_paths):
            # generates a thumbnail preview for a file.
            filepath = os.path.join(directory, name)
            thumb = pcoll.load(filepath, filepath, 'IMAGE')
            enum_items.append((name, name, "", thumb.icon_id, i))

    pcoll.my_previews = enum_items
    pcoll.my_previews_dir = directory
    return pcoll.my_previews

def update_func(self, context):
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()


    pcoll = bpy.utils.previews.new()
    pcoll.my_previews_dir = ""
    pcoll.my_previews = ()
    preview_collections["main"] = pcoll
    '''
    bpy.types.WindowManager.my_previews = EnumProperty(
        items=enum_previews_from_directory_items
        )
    '''

    return None

def register():
    import bpy
    try: bpy.utils.register_module(__name__)
    except: traceback.print_exc()

    print("Registered {} with {} modules".format(bl_info["name"], len(modules)))
    
    
    from bpy.types import (
            WindowManager,
            Scene
            )
    from bpy.props import (
            StringProperty,
            EnumProperty,
            IntProperty,
            FloatProperty,
            FloatVectorProperty,
            BoolProperty
            )
    
    # Board variables
    Scene.num_columns = IntProperty(
                                            name="Columns", 
                                            description="Number of columns for your board", 
                                            default=2, 
                                            set=None)
    Scene.num_lines = IntProperty(
                                            name="Rows", 
                                            description="Number of lines for your board", 
                                            default=2, 
                                            set=None)
    Scene.cell_size = FloatProperty(
                                            name="Cell Size", 
                                            description="Size of your cells", 
                                            default=20, 
                                            unit = 'LENGTH')
    Scene.cell_margin = FloatProperty(
                                            name="Cell Margin", 
                                            description="Size of the margin between cells", 
                                            default=0.5, 
                                            unit = 'LENGTH')
    Scene.margin_color = FloatVectorProperty(  
                                           name="Margin & Rooms Color",
                                           subtype='COLOR',
                                           default=(0,0,0),
                                           min=0.0, max=1.0,
                                           description="Margin Color")
    Scene.room_walls = IntProperty(
                                            name="Wall thickness", 
                                            description="Thickness of the walls", 
                                            default=3, 
                                            set=None)
    Scene.room_offset = IntProperty(
                                            name="Walls offset", 
                                            description="Set the walls inward (-1) or outward (1)", 
                                            default=0,
                                            max=1,
                                            min=-1,
                                            set=None)                                            
    # Texture variables
    Scene.grunge_map = BoolProperty(
                                            name="Apply as grunge", 
                                            default=False
                                        )    
    
    # Dummy variables
    Scene.dummy_width = FloatProperty(
                                            name="Width", 
                                            description="Basis of the figure", 
                                            default=20,
                                            step=10, 
                                            unit = 'LENGTH')
    Scene.dummy_height = FloatProperty(
                                            name="Height", 
                                            description="Height of the figure", 
                                            default=40,
                                            step=10, 
                                            unit = 'LENGTH')                                   
    
    # Light Variables
    Scene.light_color = FloatVectorProperty(  
                                           name="Light Color",
                                           subtype='COLOR',
                                           default=(1,1,1),
                                           min=0.0, max=1.0,
                                           description="Ligth Color")
    Scene.light_strength = IntProperty(
                                            name="Light Strength", 
                                            description="Strength for the light", 
                                            default=50000, 
                                            set=None)
    
    # Printing Variables
    Scene.bake_quality = EnumProperty(
                                            items=[('1k','1K - 1024px',''),('2k','2k - 2048px',''),('4k','4k - 4096px','')],
                                            name="Quality", 
                                            description="Caution: each additionnal step increases the previous bake time 4x", 
                                            default='1k', 
                                            set=None)
    Scene.bake_furniture = BoolProperty(
                                            name="Bake Selected Elements too", 
                                            default=False
                                        )    
    ###
    WindowManager.my_previews_dir = StringProperty(
            name="Folder Path",
            subtype='DIR_PATH',
            default="",
            update=update_func
            )

    WindowManager.my_previews = EnumProperty(
            items=enum_previews_from_directory_items,
            update=update_func
            )

    # Note that preview collections returned by bpy.utils.previews
    # are regular Python objects - you can use them to store custom data.
    #
    # This is especially useful here, since:
    # - It avoids us regenerating the whole enum over and over.
    # - It can store enum_items' strings
    #   (remember you have to keep those strings somewhere in py,
    #   else they get freed and Blender references invalid memory!).
    import bpy.utils.previews
    pcoll = bpy.utils.previews.new()
    pcoll.my_previews_dir = ""
    pcoll.my_previews = ()

    preview_collections["main"] = pcoll
    
    #bpy.utils.register_class(PreviewsExamplePanel)
 
    
def unregister():
    try: bpy.utils.unregister_module(__name__)
    except: traceback.print_exc()

    print("Unregistered {}".format(bl_info["name"]))

    from bpy.types import (
                WindowManager,
                Scene
                )
    
    Scene.num_columns
    Scene.num_lines
    Scene.cell_size
    Scene.cell_margin
    Scene.margin_color
    Scene.light_color
    Scene.light_strength
    Scene.bake_quality
    Scene.bake_furniture
    Scene.room_walls
    Scene.room_offset
    Scene.grunge_map
    Scene.dummy_width
    Scene.dummy_height
    
    ###
    del WindowManager.my_previews

    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()

    #bpy.utils.unregister_class(PreviewsExamplePanel)

