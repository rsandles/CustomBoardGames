import bpy
import os
import sys

def add_img_light(img_file,scale_x,scale_y,strength,repeat):
    
    sc = bpy.data.scenes["Scene"]
    wm = bpy.context.window_manager
    
    # Add a new spotlamp
    name = "spot"
    spot_data = bpy.data.lamps.new(name=name,type='SPOT')
    spot = bpy.data.objects.new(name=name,object_data=spot_data)
    bpy.context.scene.objects.link(spot)
    
    # Place it where the cursor is
    
    # Change its material
    mat = spot.data
    mat.use_nodes = True
    
    emission = mat.node_tree.nodes["Emission"]
    emission.inputs[1].default_value = strength
    
    image = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
    image.location = -400,400
    
    mapping = mat.node_tree.nodes.new(type='ShaderNodeMapping')
    mapping.location = -800,400
    mapping.translation[0] = 0.5
    mapping.translation[1] = 0.5
    mapping.use_min = repeat
    mapping.use_max = repeat
    mapping.scale[0] = scale_x
    mapping.scale[1] = scale_y
    
    coord = mat.node_tree.nodes.new(type='ShaderNodeTexCoord')
    coord.location = -1200,400
    
    # Link all nodes
    mat.node_tree.links.new(emission.inputs['Color'],image.outputs['Color'])
    mat.node_tree.links.new(image.inputs['Vector'],mapping.outputs['Vector'])
    mat.node_tree.links.new(mapping.inputs['Vector'],coord.outputs['Normal'])
    
    # Add the image
    if wm.light_img:
        bpy.ops.image.open(filepath = wm.light_img)
    
    proj = os.path.basename(bpy.path.abspath(wm.light_img))
    print(bpy.path.abspath(wm.light_img))
    
    image.image = bpy.data.images[proj]
    
    # Move the spot to cursor
    window = bpy.context.space_data
    
    spot.location[0] = window.cursor_location[0]
    spot.location[1] = window.cursor_location[1]
    spot.location[2] = sc.cell_size*2/3
    
    bpy.context.scene.objects.active = spot
    spot.select = True

class AddImageLight(bpy.types.Operator):
    bl_idname = "my_operator.add_image_light"
    bl_label = "Add Image Light"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    
    
    scale_x = bpy.props.FloatProperty(
                                        name="Scale on x", 
                                        description="", 
                                        default=1,
                                        step=0.1) 
    scale_y = bpy.props.FloatProperty(
                                        name="Scale on y", 
                                        description="", 
                                        default=1,
                                        step=0.1)
    strength = bpy.props.IntProperty(
                                        name="Projector Power", 
                                        description="", 
                                        default=300000,
                                        step=20000)
    repeat = bpy.props.BoolProperty(
                                        name="Single Image", 
                                        description="", 
                                        default=True)
                                            
    @classmethod
    def poll(cls, context):
        wm = context.window_manager
        return wm.light_img

    def execute(self, context):
        sc = bpy.data.scenes["Scene"]
        wm = context.window_manager
        add_img_light(wm.light_img,self.scale_x,self.scale_y,self.strength,self.repeat)
        return {"FINISHED"}
        