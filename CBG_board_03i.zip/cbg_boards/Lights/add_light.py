import bpy
import copy
from bpy.props import *

def create_light(context,ligth_height,light_strength,light_color):
    #sc = bpy.data.scenes["Scene"]
    
    obj = context.active_object
    loc_x = obj.location[0]
    loc_y = obj.location[1]
    
    lamp_count =  [l for l in bpy.data.lamps if "Lamp" in l.name]
    
    i = 1
    for l in lamp_count:
        l.name = "Lamp."+str(len(lamp_count)+i)
        i += 1
    
    lamp_name = "Lamp."+str(len(lamp_count)+i)
    lamp_data = bpy.data.lamps.new(lamp_name,'POINT')
    lamp = bpy.data.objects.new(lamp_name,lamp_data)
    context.scene.objects.link(lamp)
    
    lamp.location = (loc_x,loc_y,ligth_height)
    
    #lamp.select = True
    #context.scene.objects.active = lamp
    
    data = bpy.data.lamps[lamp_name]
    # Decompose the color stored in sc.light_color to make it fit the node
    #red = sc.light_color[0]
    #green = sc.light_color[1]
    #blue = sc.light_color[2]
    red = light_color[0]
    green = light_color[1]
    blue = light_color[2]
    
    data.use_nodes =  True
    data.node_tree.nodes["Emission"].inputs[0].default_value = (red,green,blue,1)
    data.node_tree.nodes["Emission"].inputs[1].default_value = light_strength
    
    for l in lamp_count:
        lamp_count.remove(l)
    
class CreateLight(bpy.types.Operator):
    bl_idname = "my_operator.create_light"
    bl_label = "Create Light"
    bl_description = "Creates a light above the selected cell"
    bl_options = {"REGISTER","UNDO"}

    light_height = FloatProperty(
                                            name="Light Height", 
                                            description="Height of the light", 
                                            default = 50,
                                            step = 100, 
                                            unit = 'LENGTH',
                                            options={'SKIP_SAVE'})
    light_strength = IntProperty(
                                            name="Light Strength", 
                                            description="Strength of the light", 
                                            default = 50000,
                                            step = 100,
                                            options={'SKIP_SAVE'}
                                           )
    light_color = FloatVectorProperty(  
                                           name="Light Color",
                                           subtype='COLOR',
                                           default=(1,1,1),
                                           min=0.0, max=1.0,
                                           description="Light Color",
                                           options={'SKIP_SAVE'}
                                           )                                     

    @classmethod
    def poll(cls, context):
        obj = bpy.context.active_object
        return obj is not None and "Cell" in obj.name

    def execute(self, context):
        #sc = bpy.data.scenes["Scene"]
        create_light(context,self.light_height,self.light_strength,self.light_color)
        return {"FINISHED"}

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
