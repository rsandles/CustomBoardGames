import bpy

#sc = bpy.data.scenes["Scene"]

def add_walls(wall_height):
    
    myselection = [o for o in bpy.context.selected_objects if "Cell" in o.name]
    walls = []
    
    for obj in myselection:
        newobj = obj.copy()
        newobj.data = obj.data.copy()
        bpy.context.scene.objects.link(newobj)
        walls.append(newobj)
    
    bpy.ops.object.select_all(action='DESELECT')
    
    for o in walls:
        o.select = True
        bpy.context.scene.objects.active = o
        o.cycles_visibility.camera = False
        o.cycles_visibility.diffuse = False
        o.cycles_visibility.glossy = False
        o.cycles_visibility.transmission = False
        o.cycles_visibility.scatter = False
        o.draw_type = 'WIRE'
        o.name = "walls"
    
    bpy.ops.object.join()

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.mesh.delete(type='ONLY_FACE')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='EDGE')    
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, wall_height), "constraint_axis":(False, False, True), "constraint_orientation":'GLOBAL'})
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    obj = bpy.context.active_object
    obj.name = "Walls"

from bpy.props import *


class AddWalls(bpy.types.Operator):
    bl_idname = "my_operator.add_walls"
    bl_label = "Add Walls"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}
    
    

    wall_height = FloatProperty(
                                            name="Wall Height", 
                                            description="Height of the walls", 
                                            default = 50,
                                            step = 100, 
                                            unit = 'LENGTH')

    @classmethod
    def poll(cls, context):
        return context.selected_objects is not None

    def execute(self, context):
        add_walls(self.wall_height)
        return {"FINISHED"}
        
def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()

    
    