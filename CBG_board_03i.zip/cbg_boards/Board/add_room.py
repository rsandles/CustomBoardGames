import bpy

def add_room():
    
    sc = bpy.data.scenes["Scene"]
    
    myselection = [o for o in bpy.context.selected_objects if "Cell" in o.name]
    room = []
    
    for obj in myselection:
        newobj = obj.copy()
        newobj.data = obj.data.copy()
        bpy.context.scene.objects.link(newobj)
        room.append(newobj)
    
    bpy.ops.object.select_all(action='DESELECT') 
    
    for o in room:
        o.select = True
        bpy.context.scene.objects.active = o
        cyc = o.cycles_visibility
        cyc.shadow = False
        cyc.glossy = False
        cyc.is_shadow_catcher = False
        cyc.transmission = False
        cyc.scatter = False
        
        
        
    
    # Merge all the selected cells
    bpy.ops.object.join()

    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.mesh.delete(type='ONLY_FACE')
    bpy.ops.mesh.select_mode(type='EDGE')    
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"mirror":False}, TRANSFORM_OT_translate={"value":(0, 0, 1), "constraint_axis":(False, False, True), "constraint_orientation":'GLOBAL'})
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent()
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    obj = bpy.context.active_object
    obj.name = "Room"
    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
    
    # Add a solidify modifier
    solid = obj.modifiers.new(name="SOLID",type='SOLIDIFY')
    solid.use_even_offset = True
    solid.use_quality_normals = True
    solid.thickness = sc.room_walls
    solid.offset = sc.room_offset
    bpy.ops.object.modifier_apply(modifier = "SOLID")
    
    # Remove previous materials and set a white one
    for m in range(len(obj.material_slots)) :
        bpy.ops.object.material_slot_remove()
    
    room_mat = bpy.data.materials.new('Room')
    obj.data.materials.append(room_mat)
    obj.active_material.use_nodes = True
    obj.data.materials[room_mat.name].node_tree.nodes["Diffuse BSDF"].inputs[0].default_value = (sc.margin_color[0],sc.margin_color[1],sc.margin_color[2],1)

class AddRoom(bpy.types.Operator):
    bl_idname = "my_operator.add_room"
    bl_label = "Add Room"
    bl_description = "Adds a room contour to the selected cells"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "Cell" in obj.name

    def execute(self, context):
        add_room()
        return {"FINISHED"}
        