import bpy

class SimpleBoard(bpy.types.Panel):
    bl_idname = "Board"
    bl_label = "Board Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_category = "CBG Boards"

    def draw(self, context):
        
        sc = bpy.data.scenes["Scene"]
        
        layout = self.layout
        
        row = layout.row(align = True)
        
        row = layout.box()
        row.prop(sc,"num_columns")
        row.prop(sc,"num_lines")
        #row = layout.row()
        
        row.prop(sc,"cell_size")
        row.prop(sc,"cell_margin")
        row.prop(sc,"margin_color")
        row = layout.row()
        row.label("Operations")
        row = layout.row()
        row.operator("my_operator.createboard", text="Create",icon = 'PLUS')
        row = layout.row(align = True)
        row.operator("my_operator.merge_cells", text="Merge Cells",icon = 'ARROW_LEFTRIGHT')
        row.operator("my_operator.subdivide_cell", text="Split Cell",icon = 'GRID')
                
        

class TexturePreviews(bpy.types.Panel):
    """Creates a Previews Panel"""
    bl_label = "Textures & Stickers"
    bl_idname = "OBJECT_PT_previews"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category = "CBG Boards"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        sc = bpy.data.scenes["Scene"]

        row = layout.row()
        row.prop(wm, "my_previews_dir")
        
        row = layout.row()
        row.template_icon_view(wm, "my_previews")
        
        row = layout.row()
        row.operator("paper.create_material", text="Apply as Material",icon = 'FILE_IMAGE')
        
        row = layout.row()
        row.operator("paper.add_decal", text="Apply as Sticker",icon = 'GHOST')

class LigthsShadows(bpy.types.Panel):
    bl_idname = "Lighting"
    bl_label = "Lights & Shadows"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_category = "CBG Boards"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        
        sc = bpy.data.scenes["Scene"]
        
        layout = self.layout
        
        box = layout.box()
        box.label("Select cell(s) / room")
        box.operator("my_operator.add_walls", text="Project Shadows",icon = 'IMAGE_ALPHA')
        
        box = layout.box()
        box.label("Add a light above cell")
        box.prop(sc,"light_color")
        box.prop(sc,"light_strength")
        box.operator("my_operator.create_light", text="Add a light",icon = 'LAMP_POINT')
      
class PrintOperations(bpy.types.Panel):
    bl_idname = "print_operations"
    bl_label = "Printing Operations"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_category = "CBG Boards"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        
        row = layout.row()
        row.label("Step 1 - Create a duplicate on layer 2")
        box = layout.box()
        row = box.row()
        row.label("Select Cells to assemble first")
        row = box.row()
        row.operator("my_operator.duplicate_bake", text="Assemble Selection",icon = 'UV_ISLANDSEL')
        row = box.row()
        row.label("Or")
        row = box.row()
        row.operator("my_operator.duplicate_bake_all", text="Assemble All Cells",icon = 'MESH_GRID')
        
        row = layout.row()
        row.label("Step 2 - Bake a single image")
        box = layout.box()
        row = box.row()
        row.label("This may take a LONG time",icon='QUESTION')
        row = box.row()
        row.operator("my_operator.bake_material", text="Bake Textures",icon = 'SCENE')
        
        row = layout.row()
        row.label("Step 3 - Apply the baked image")
        box = layout.box()
        row = box.row()
        row.label("Select the board on layer 2",icon='QUESTION')
        row = box.row()
        row.operator("my_operator.blender_render", text="Apply to Duplicate",icon = 'RENDER_RESULT')
        
        row = layout.row()
        row.label("Step 4 - Export for printing")
        box = layout.box()
        row = box.row()
        row.label("Select the board on layer 2",icon='QUESTION')
        row = box.row()
        row.operator("export_mesh.paper_model",icon="RENDER_RESULT",text="Export")
        
        row = layout.row()
        row.label("Step 5 - Reset & Continue")
        box = layout.box()
        row = box.row()
        row.operator("my_operator.set_render_engine",icon="FILE_TICK",text="Reset")