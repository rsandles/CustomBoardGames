import bpy

def bake_material(context):
    
    myselection = bpy.context.active_object
    mydupli = bpy.data.objects[myselection.name+"_BAKE"]
    mymat = mydupli.active_material
    bake_texture = mymat.node_tree.nodes.new(type='ShaderNodeTexImage')
    bake_texture.image = bpy.data.images[myselection.name + "_BAKE"]
    
    baked_objects = [obj for obj in bpy.context.visible_objects if myselection.name in obj.name]
    print(baked_objects)
    
    for ob in baked_objects :
        ob.select = True
    
    bpy.context.scene.objects.active = mydupli
    
    bpy.context.scene.layers[0] = True
    bpy.context.scene.layers[1] = True
    
    myselection.active_material.node_tree.nodes.active = bake_texture
    bpy.data.scenes["Scene"].render.bake.use_pass_direct = True
    bpy.data.scenes["Scene"].render.bake.use_pass_indirect = True
    bpy.ops.object.bake(
                        type='COMBINED',
                        use_selected_to_active=True,
                        cage_extrusion=3
                        )

class BakeMaterial(bpy.types.Operator):
    bl_idname = "my_operator.bake_material"
    bl_label = "Bake Material"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "Board" in obj.name and not "_BAKE" in obj.name

    def execute(self, context):
        bake_material(context)
        return {"FINISHED"}
    
def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
