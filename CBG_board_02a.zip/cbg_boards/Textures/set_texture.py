
import os
import os.path
from os import path

import bpy

def apply_texture(context,texture_scale):
    
    sc = bpy.data.scenes["Scene"]
    
    myactive = bpy.context.active_object
    myselection = context.selected_objects
    
    wm = context.window_manager
    mat_name = wm.my_previews
    
    # Delete all previous materials
    '''
    for obj in myselection:
        bpy.context.scene.objects.active = obj
        for m in obj.material_slots :
            print(m)
            #bpy.ops.object.material_slot_remove()
    '''
    mat = bpy.data.materials.new(mat_name) # Add some checks to see if the material already exists
    
    normal_img = wm.my_previews_dir + "normal_" + wm.my_previews
    roughness_img = wm.my_previews_dir + "roughness_" + wm.my_previews
    ao_img = wm.my_previews_dir + "AO_" + wm.my_previews
    
    mat.use_nodes = True
    
    # --------------------------------------------------------------------------
    # Enter all the nodes here and name them for future use by other functions
    # --------------------------------------------------------------------------
    
    surface = mat.node_tree.nodes['Material Output']
    surface.name = "surface"
    surface.location = 1000,0
    
    principled = mat.node_tree.nodes.new(type='ShaderNodeBsdfPrincipled')
    principled.name = "principled"
    principled.location = 700,0
    
    diffuse = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
    diffuse.name = "diffuse"
    diffuse.location = 0, 200
    
    normal = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
    normal.name = "normal"
    normal.location = 0,-400
    normal_map = mat.node_tree.nodes.new(type='ShaderNodeNormalMap')
    normal_map.name = "normal_map"
    normal_map.location = 400,-400
    
    roughness = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
    roughness.name = "roughness"
    roughness.location = 0, -100
    
    if path.exists(ao_img) :
        ao = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
        ao.name = "ambient_occlusion"
        ao.location = 0,500
        ao.color_space = 'COLOR'
            
        ao_mixrgb = mat.node_tree.nodes.new(type='ShaderNodeMixRGB')
        ao_mixrgb.name = "ao_mixrgb"
        ao_mixrgb.location = 300,400
        ao_mixrgb.blend_type = 'MULTIPLY'    
    mapping = mat.node_tree.nodes.new(type='ShaderNodeMapping')
    mapping.name = "mapping"
    mapping.location = -700,0
    
    coord = mat.node_tree.nodes.new(type='ShaderNodeTexCoord')
    coord.name = "coord"
    coord.location = -1000,0
    
    # --------------------------------------------------------------------------
    # Change the nodes settings
    # --------------------------------------------------------------------------
    
    # Mapping
    mapping.scale[0] = texture_scale
    mapping.scale[1] = texture_scale
    mapping.scale[2] = texture_scale
    
    # Diffuse
    diffuse.image = bpy.data.images.load(filepath=wm.my_previews_dir + wm.my_previews)
    #'D:\\�l�ments graphiques\\textures\\walls\\TexturesCom_Generic Bricks_albedo_S.tiff')
    if "Cell" in myactive.name :
        diffuse.projection = 'FLAT'
    else :
        diffuse.projection = 'BOX'

    # Normal - Check if there is one then apply it to the node
    if path.exists(normal_img) :
        normal.image = bpy.data.images.load(filepath=normal_img)
        if "Cell" in myactive.name :
            normal.projection = 'FLAT'
        else :
            normal.projection = 'BOX'
        normal.color_space = 'NONE'
    
    # Normal map
    normal_map.inputs[0].default_value = 3 # Normal map strength
    
    # Roughness
    if path.exists(roughness_img) :
        roughness.image = bpy.data.images.load(filepath=roughness_img)
        if "Cell" in myactive.name :
            roughness.projection = 'FLAT'
        else :
            roughness.projection = 'BOX'
        roughness.color_space = 'NONE'
    
    # AO
    if path.exists(ao_img) :
        ao.image = bpy.data.images.load(filepath=ao_img)
        if "Cell" in myactive.name :
            ao.projection = 'FLAT'
        else :
            ao.projection = 'BOX'
        ao.color_space = 'COLOR'
    
    # --------------------------------------------------------------------------
    # Enter all the links between the nodes here in the form (input of one node, output of the other)
    # --------------------------------------------------------------------------
    
    # link the principled node
    mat.node_tree.links.new(surface.inputs['Surface'],principled.outputs['BSDF'])
    
    # link the diffuse color node and the coordinates
    if path.exists(ao_img) :
        mat.node_tree.links.new(principled.inputs['Base Color'],ao_mixrgb.outputs['Color'])
    else:
        mat.node_tree.links.new(principled.inputs['Base Color'],diffuse.outputs['Color'])
    mat.node_tree.links.new(diffuse.inputs['Vector'],mapping.outputs['Vector'])
    mat.node_tree.links.new(mapping.inputs['Vector'],coord.outputs['Object'])
    
    # link the normal map if it isn't empty
    if path.exists(normal_img) :
        mat.node_tree.links.new(principled.inputs['Normal'],normal_map.outputs['Normal'])
        mat.node_tree.links.new(normal_map.inputs['Color'],normal.outputs['Color'])
        mat.node_tree.links.new(normal.inputs['Vector'],mapping.outputs['Vector'])
    
    # link the roughness if it isn't empty
    if path.exists(roughness_img) :
        mat.node_tree.links.new(principled.inputs['Roughness'],roughness.outputs['Color'])
        mat.node_tree.links.new(roughness.inputs['Vector'],mapping.outputs['Vector'])
    
    # link the AO if it isn't empty
    if path.exists(ao_img) :
        mat.node_tree.links.new(ao_mixrgb.inputs['Color1'],ao.outputs['Color'])
        mat.node_tree.links.new(ao_mixrgb.inputs['Color2'],diffuse.outputs['Color'])
        mat.node_tree.links.new(ao_mixrgb.inputs['Fac'],ao.outputs['Alpha'])
        mat.node_tree.links.new(ao.inputs['Vector'],mapping.outputs['Vector'])
        
        
        
    # Apply the texture to the center face
    for obj in myselection :
        bpy.context.scene.objects.active = obj
        bpy.ops.object.material_slot_add()
        #obj.data.materials.append(mat)
        obj.active_material = mat
        for v in obj.data.vertices:
            v.select = False
        for f in obj.data.polygons:
            f.select = False
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        # Select the center face
        cur =  (0,0,0)
        faceIdx = myactive.closest_point_on_mesh(cur)[3]
        obj.data.polygons[faceIdx].select = True
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

from bpy.props import *
    
class Create_Material(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "paper.create_material"
    bl_label = "Assign Material"
    bl_options = {"REGISTER","UNDO"}
    
    texture_scale = FloatProperty(
                                            name="Scale", 
                                            description="Scale of your texture", 
                                            default=0.01,
                                            min=0.001,
                                            step=1)
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        myselection = context.selected_objects
        for obj in myselection:
            if not "Cell" in obj.name:
                obj.select = False
            else:
                context.scene.objects.active = obj
        apply_texture(context,self.texture_scale)
        return {'FINISHED'}

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()


        