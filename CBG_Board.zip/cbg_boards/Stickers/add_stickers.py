import bpy

def add_decal(context):
    
    obj = bpy.context.active_object
    thr = 2 # Define a threshold of tolerance for the face selection
    
    ###
    myselection = context.selected_objects
    
    
    '''
    # Get the face of the object on which the cursor is located
    obj_x = round(obj.location[0],2)
    obj_y = round(obj.location[1],2)
    obj_z = round(obj.location[2],2)

    cursor_x = round(bpy.context.scene.cursor_location[0],2)
    cursor_y = round(bpy.context.scene.cursor_location[1],2)
    cursor_z = round(bpy.context.scene.cursor_location[2],2)
    
    diff_x = round((cursor_x - obj_x))
    diff_y = round((cursor_y - obj_y))
    diff_z = round((cursor_z - obj_z))
    
    print(diff_x)
    print(diff_y)
    print(diff_z)
    

    for v in obj.data.vertices :
        v.select = False
    for e in obj.data.edges :
        e.select = False
    for f in obj.data.polygons :
        f.select = False
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # Select that face, which should be the one for which the center coincides with the axis found by diff
    
    minimum = 1000
    
    for face in obj.data.polygons :
        minimum_face = min(abs(face.center[0]-diff_x), abs(face.center[1]-diff_y), abs(face.center[2]-diff_z))
        print("min : " + str(minimum_face))
        if minimum_face < minimum :
            myface = face.index
            minimum = minimum_face
    '''
    
    ###
    for o in myselection :
        cur =  (0,0,0)
        myface = obj.closest_point_on_mesh(cur)[3]
        o.data.polygons[myface].select = True
    ###
    
    obj.data.polygons[myface].select = True
    
    # Copy that face, move it and separate it
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.duplicate_move()
    bpy.context.space_data.transform_orientation = 'NORMAL'
    bpy.ops.transform.translate(value=(0, 0, 10), constraint_axis=(False, False, True), constraint_orientation='NORMAL', mirror=False, proportional='DISABLED', proportional_edit_falloff='SMOOTH', proportional_size=1)
    bpy.ops.mesh.separate(type='SELECTED')
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    myselection = bpy.context.selected_objects
    bpy.context.scene.objects.active = myselection[0]
    
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    
    
    bpy.ops.view3d.snap_cursor_to_active()
    
    
    
    
    
    # Add an empty to that separated face and orient it towards the object on the -Z, which is the projection 
    # axis for the decal
    bpy.ops.object.empty_add(type='ARROWS', view_align=False, location=bpy.context.scene.cursor_location, layers=(True, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False))
    
    # Delete the face as it isn't needed anymore
    bpy.data.objects.remove(myselection[0])
    
    # Add a constraint to orient the empty opposite the selected object, projections being based on -Z axis
    empty = bpy.context.active_object
    const = empty.constraints.new(type='TRACK_TO')
    
    const.target = obj
    const.track_axis = 'TRACK_NEGATIVE_Z'
    const.up_axis = 'UP_Y'
    
    empty.show_name = True
    empty.scale = (20,20,20)
    
    bpy.ops.object.visual_transform_apply()
    
    bpy.data.objects.update()
    
    empty.constraints.remove(const)
    
    # Assign a copy of the current material to that face where the decal will be applied
    # Add the decal to the object's material

    myactive = obj
    wm = context.window_manager
    i = 0 # adds a counter to add the decal to the existing ones if there are any
    
    #--------------------------------------------------------------
    # TODO - Add a check on the material name to keep it if it has decal_
    
    if "_DECAL_" in bpy.context.scene.objects[obj.name].active_material.name:
        mat = bpy.context.scene.objects[obj.name].active_material
    else:
        mat = bpy.context.scene.objects[obj.name].active_material.copy() # Add some checks to see if the material already exists
        mat.name =  obj.name + "_DECAL_" + "FACE" + str(myface)
        obj.data.materials.append(mat)
        obj.active_material_index = len(obj.data.materials)-1
    
    context.scene.objects.active = obj
    obj.data.polygons[myface].select = True
    
    print("selected face : " + str(myface))
    
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.object.material_slot_assign()
    bpy.ops.object.mode_set(mode='OBJECT')
    
    normal_img = wm.my_previews_dir + "normal_" + wm.my_previews
    roughness_img = wm.my_previews_dir + "roughness_" + wm.my_previews
    
    mat.use_nodes = True
    
    # --------------------------------------------------------------------------
    # Enter all the nodes here
    # see : https://docs.blender.org/api/blender_python_api_2_68a_release/bpy.types.ShaderNode.html
    # --------------------------------------------------------------------------
    
    # Count the other decals first
    
    diffuse_list = [node for node in mat.node_tree.nodes if node.type == 'MIX_RGB']
    print(diffuse_list)
    
    decal = mat.node_tree.nodes.new(type='ShaderNodeTexImage')
    decal.name = "Decal"
    decal.location = 0, (len(diffuse_list)*300)+700
    '''
    mix = mat.node_tree.nodes.new(type='ShaderNodeMixRGB')
    '''
    mapping = mat.node_tree.nodes.new(type='ShaderNodeMapping')
    mapping.location = -700, (len(diffuse_list)*300)+700
    
    coord = mat.node_tree.nodes.new(type='ShaderNodeTexCoord')
    coord.location = -1000, (len(diffuse_list)*300)+700
    
    # --------------------------------------------------------------------------
    # Change the nodes settings
    # --------------------------------------------------------------------------
    
    # Coordinates
    empty.name = "DECAL_" + wm.my_previews
    coord.object = empty
    
    # Mapping
    mapping.scale[0] = 1
    mapping.scale[1] = 1
    mapping.scale[2] = 1
    mapping.translation[0] = 0.5 #necessary to center the image relative to the empty
    mapping.translation[1] = 0.5
    
    # Decal
    decal.image = bpy.data.images.load(filepath=wm.my_previews_dir + wm.my_previews)
    decal.projection = 'FLAT'
    decal.extension = 'CLIP'
    
    # Recover Diffuse and Principled nodes
    
    # Check if the diffuse is already mixed, if so is it with an AO, to find the last MIX_RGB to connect to
    if len(diffuse_list) != 0:
        if len(diffuse_list) == 1 and "ao_mixrgb" in mat.node_tree.nodes:
            diffuse = mat.node_tree.nodes["ao_mixrgb"]
        else:
            mix_list = [node.name for node in mat.node_tree.nodes if "Decal_mix" in node.name]
            diffuse = mat.node_tree.nodes[mix_list[-1]]
    else :
        diffuse_list = [node for node in mat.node_tree.nodes if node.type == 'TEX_IMAGE' and node.color_space == 'COLOR']
        diffuse = diffuse_list[0]
        
        
    mix = mat.node_tree.nodes.new(type='ShaderNodeMixRGB')
    mix.location = 300,(len(diffuse_list)*300)+400
    
    principled_list = [node for node in mat.node_tree.nodes if node.type == 'BSDF_PRINCIPLED']
    principled = principled_list[0]
    
    # --------------------------------------------------------------------------
    # Enter all the links between the nodes here in the form (input of one node, output of the other)
    # --------------------------------------------------------------------------
    
    # link the decal node 
    mat.node_tree.links.new(decal.inputs['Vector'],mapping.outputs['Vector'])
    mat.node_tree.links.new(mapping.inputs['Vector'],coord.outputs['Object'])
    
    # Link the mix node
    mat.node_tree.links.new(mix.inputs['Color2'],decal.outputs['Color'])
    mat.node_tree.links.new(mix.inputs['Color1'],diffuse.outputs['Color'])
    mat.node_tree.links.new(mix.inputs['Fac'],decal.outputs['Alpha'])
    
    # Link the principled node
    mat.node_tree.links.new(principled.inputs['Base Color'],mix.outputs['Color'])
    ###
    
    # Rename the mix so the next decal can find this name to connect to   
    mix.name = "Decal_mix"
    
    ''' OLD
    diffuse = diffuse_list[0]
    principled = principled_list[0]
    
    # --------------------------------------------------------------------------
    # Enter all the links between the nodes here in the form (input of one node, output of the other)
    # --------------------------------------------------------------------------
    
    # link the decal node 
    mat.node_tree.links.new(decal.inputs['Vector'],mapping.outputs['Vector'])
    mat.node_tree.links.new(mapping.inputs['Vector'],coord.outputs['Object'])
    
    # Link the mix node
    mat.node_tree.links.new(mix.inputs['Color2'],decal.outputs['Color'])
    mat.node_tree.links.new(mix.inputs['Color1'],diffuse.outputs['Color'])
    mat.node_tree.links.new(mix.inputs['Fac'],decal.outputs['Alpha'])
    
    # Link the principled node
    mat.node_tree.links.new(principled.inputs['Base Color'],mix.outputs['Color'])
    '''
    
    
    myactive.active_material = mat
    
    # Parent the empty to the object
    obj.select = True
    empty.select = True
    bpy.context.scene.objects.active = obj
    bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
    bpy.context.scene.objects.active = empty
    obj.select = False

class AddDecal(bpy.types.Operator):
    bl_idname = "paper.add_decal"
    bl_label = "Add Decal"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        add_decal(context)
        return {"FINISHED"}
        

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
