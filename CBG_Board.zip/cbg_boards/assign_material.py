import bpy


def create_material(mat_name):
    
    myactive = bpy.context.active_object
    
    sc = bpy.data.scenes["Scene"]
    
    mat = bpy.data.materials.new(mat_name) # Add some checks to see if the material already exists
    
    mat.use_nodes = True
    
    # --------------------------------------------------------------------------
    # Enter all the nodes here and name them for future use by other functions
    # --------------------------------------------------------------------------
    
    surface = mat.node_tree.nodes['Material Output']
    surface.name = "surface"
    diffuse = mat.node_tree.nodes.new(type='ShaderNodeBsdfDiffuse')
    diffuse.name = "diffuse"
    
    # --------------------------------------------------------------------------
    # Change the nodes settings
    # --------------------------------------------------------------------------
    
    
    # Diffuse
    diffuse.inputs[0].default_value = (sc.margin_color[0],sc.margin_color[1],sc.margin_color[2],1)

    
    # --------------------------------------------------------------------------
    # Enter all the links between the nodes here in the form (input of one node, output of the other)
    # --------------------------------------------------------------------------
    
    # link the principled node
    mat.node_tree.links.new(surface.inputs['Surface'],diffuse.outputs['BSDF'])
    
    myactive.active_material = mat

class CreateMaterial(bpy.types.Operator):
    bl_idname = "my_operator.create_material"
    bl_label = "Create Material"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        
        sc = bpy.data.scenes["Scene"]
        
        create_material("Margin."+str(sc.margin_color))
        return {"FINISHED"}
        

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()


    
