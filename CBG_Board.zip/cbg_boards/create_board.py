import bpy


def create_cell(cell_size,cell_margin,margin_color,cell_name):
    
    # Define the cells
    
    name = cell_name
    verts = [
            ( -(cell_size/2) , -(cell_size/2) , 0.0 ),
            ( (cell_size/2) , -(cell_size/2) , 0.0 ),
            ( -(cell_size/2) , (cell_size/2) , 0.0 ),
            ( (cell_size/2) , (cell_size/2) , 0.0 ),
            ( -(cell_size/2-cell_margin) , (cell_size/2-cell_margin) , 0.0 ),
            ( -(cell_size/2-cell_margin) , -(cell_size/2-cell_margin) , 0.0 ),
            ( (cell_size/2-cell_margin) , -(cell_size/2-cell_margin) , 0.0 ),
            ( (cell_size/2-cell_margin) , (cell_size/2-cell_margin) , 0.0 )
            ]
    faces = [
            ( 5 , 6 , 7 , 4 ) ,
            ( 5 , 4 , 2 , 0 ) ,
            ( 6 , 5 , 0 , 1 ) ,
            ( 7 , 6 , 1 , 3 ) ,
            ( 4 , 7 , 3 , 2 )
            ]
    margins  = [faces[1],faces[2],faces[3],faces[4]]
    
    
    # Create the mesh and add the object to the scene
    
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts,[],faces)
    
    obj = bpy.data.objects.new(name,mesh)
    bpy.context.scene.objects.link(obj)
    
    # Select the object cell and make it the active one
    bpy.context.scene.objects.active = obj
    obj.select = True
    
    # Create vertex groups so it becomes easier to assign materials
    #margin_vg = obj.vertex_groups.new(name = "Margins")
    #main_face_vg = obj.vertex_groups.new(name = "Face")
    
    # Add the color to the margins
    bpy.ops.object.material_slot_add()
    ob = bpy.context.active_object
    slot = ob.material_slots[ob.active_material_index]
    
    # Add an outline to the cell
    ob.show_wire = True

def create_board(columns,lines,cell_size):
    
    sc = bpy.data.scenes["Scene"]
    
    # Set some counters for the while loops
    col = 0
    lin = 0
    
    # Variables to set the board at the center of the scene
    col_origin = -(cell_size*columns/2 - cell_size/2)
    lin_origin = -(cell_size*lines/2 - cell_size/2)
    

    # Create the board cell by cell
    while lin < lines:
        while col < columns:
            cell_name = "Cell."+ str(chr(97+col)) + str(lines-lin)
            create_cell(sc.cell_size,sc.cell_margin,sc.margin_color,cell_name)
            obj = bpy.context.active_object
            obj.location[0] = col_origin + cell_size*col
            obj.location[1] = lin_origin + cell_size*lin
            col += 1
            
            # Assign the color to the margins

            vert = obj.data.vertices
            faces = obj.data.polygons   
               
            bpy.ops.object.material_slot_add()
            bpy.ops.my_operator.create_material()
            
            for v in vert:
                v.select = False
            
            for f in faces:
                f.select = False
                        
            for f in faces[1:5]:
                f.select = True
            
            bpy.ops.object.mode_set(mode = 'EDIT')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
            slot = obj.material_slots[obj.active_material_index]
            current_mat_name = "Margin." + str(sc.margin_color)
            mat = bpy.data.materials[current_mat_name]
            slot.material = mat
            bpy.ops.object.material_slot_assign()
            bpy.ops.object.mode_set(mode = 'OBJECT')
            

            
            
        col = 0
        lin += 1

def set_material_to_center_face(context):
    
    sc = bpy.data.scenes["Scene"]
    
    myactive = bpy.context.active_object
    
    cur = (0,0,0)
    
    faceIdx = myactive.closest_point_on_mesh(cur)[3]
    
    print(faceIdx)
    
    myactive.data.polygons[faceIdx].select = True
        
    bpy.ops.object.mode_set(mode = 'EDIT')
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.context.object.active_material_index = 0
    bpy.ops.object.material_slot_assign()
    bpy.ops.object.mode_set(mode = 'OBJECT')

def merge_cells(context):
    
    sc = bpy.data.scenes["Scene"]
    
    myselection = bpy.context.selected_objects
    
    myactive = bpy.context.active_object
    
    mat = myactive.active_material
    
    # Merge all the objects
    bpy.ops.object.join()
        
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.mesh.dissolve_limited()
    
    # Recreate the margin
    bpy.ops.mesh.inset(thickness=sc.cell_margin, depth=0)
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # Select the center face
    '''
    myactive = bpy.context.active_object
    #bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
    
    cur = (0,0,0)
    
    faceIdx = myactive.closest_point_on_mesh(cur)[3]
    
    print(faceIdx)
    
    myactive.data.polygons[faceIdx].select = True
        
    bpy.ops.object.mode_set(mode = 'EDIT')
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.context.object.active_material_index = 0
    bpy.ops.object.material_slot_assign()
    bpy.ops.object.mode_set(mode = 'OBJECT')
    '''
    set_material_to_center_face(context)
    
    
    #myactive = bpy.context.active_object

def subdivide_cell(context):
    
    sc = bpy.data.scenes["Scene"]
    
    myselection = context.selected_objects
    myactive = context.active_object
    name = myactive.name
    
    # Merge and Subdivide the cell
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.mesh.subdivide(smoothness=0)
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    # Recreate the margin for each subcell and make them independent
    i = len(myactive.data.polygons) # just a counter to break the loop when there's just one face left
    for f in reversed(myactive.data.polygons):
        f.select = True
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.inset(thickness=sc.cell_margin, depth=0)
        print(f.index)
        if i == 1:
            bpy.ops.object.mode_set(mode = 'OBJECT')
            break
        else:
            bpy.ops.mesh.select_more()
            bpy.ops.mesh.separate(type = 'SELECTED')
            bpy.ops.object.mode_set(mode = 'OBJECT')
            i -= 1
    
    myselection = context.selected_objects
    
    for obj in myselection:
        bpy.context.scene.objects.active =  obj
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        set_material_to_center_face(context)
        
        #bpy.ops.mesh.inset(thickness=sc.cell_margin, depth=0, use_individual=True)
    '''
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.scene.objects[name].select = True
    bpy.ops.object.delete()
    '''


      
    

class CreateBoard(bpy.types.Operator):
    bl_idname = "my_operator.createboard"
    bl_label = "Createboard"
    bl_description = "Creates a board with the specified dimensions"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        
        sc = bpy.data.scenes["Scene"]
        create_board(sc.num_columns,sc.num_lines,sc.cell_size)
        return {"FINISHED"}

class MergeCells(bpy.types.Operator):
    bl_idname = "my_operator.merge_cells"
    bl_label = "Merge Cells"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "Cell" in obj.name

    def execute(self, context):
        merge_cells(context)
        return {"FINISHED"}

class SubdivideCell(bpy.types.Operator):
    bl_idname = "my_operator.subdivide_cell"
    bl_label = "Subdivide selected Cells"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "Cell" in obj.name

    def execute(self, context):
        subdivide_cell(context)
        return {"FINISHED"}

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
