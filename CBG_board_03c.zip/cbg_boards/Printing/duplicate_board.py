import bpy

def join_board(context):
    
    sel_obj = bpy.context.selected_objects
    
    myselection = [c for c in sel_obj if "Cell" in c.name]
    
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in myselection:
        obj.select = True
        context.scene.objects.active = obj
       
    '''
    #
    bpy.ops.object.select_all(action='DESELECT')
    boards = [b for b in bpy.data.groups if "Board" in b.name]
    gr = bpy.data.groups.new("Board"+str(len(boards)+1))
    
    for o in myselection:
        o.select = True
        context.scene.objects.active = o
        gr.objects.link(o)
    #
    '''
    
    bpy.ops.object.join()
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    obj = bpy.context.active_object
    
    boards = [b for b in bpy.context.selectable_objects if "Board" in b.name]
    
    obj.name = "Board"+str(len(boards)+1)
    
    # Reselect the original selection 
    for obj in sel_obj:
        obj.select = True
    
def join_board_all(context):
    
    bpy.ops.object.select_all(action='DESELECT')

    for obj in context.selectable_objects:
        if "Cell" in obj.name:
            obj.select = True
            context.scene.objects.active = obj
    
    bpy.ops.object.join()
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    obj = bpy.context.active_object
    
    boards = [b for b in bpy.context.selectable_objects if "Board" in b.name]
    
    obj.name = "Board"+str(len(boards)+1)

def duplicate_bake(context):
    
    myactive = bpy.context.active_object
    '''
    ##
    myselection = context.selected_objects
    group = bpy.data.objects[myactive.name].users_group[-1]
    for obj in group.objects:
        newobj = obj.copy()
        newobj.data = obj.data.copy()
        newobj.name = obj.name + "_COPY"
        bpy.context.scene.objects.link(newobj)
        bpy.data.meshes.update()
    
    for obj in context.selected_objects:
        if "_COPY" in obj.name:
            obj.select = True
            context.scene.objects.active = obj
        else:
            obj.select = False
    
    bpy.ops.object.join()
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.object.mode_set(mode = 'OBJECT')
    
    newobj = bpy.context.active_object
    
    boards = [b for b in bpy.data.groups if "Board" in b.name]

    newobj.name = "Board"+str(len(boards)+1)
    
    # Unwrap this new object
    myactive.select = False
    bpy.context.scene.objects.active = newobj
    
    # Make this object invisble to cyles
    newobj.cycles_visibility.camera = False
    newobj.cycles_visibility.diffuse = False
    newobj.cycles_visibility.glossy = False
    newobj.cycles_visibility.transmission = False
    newobj.cycles_visibility.scatter = False
    newobj.cycles_visibility.shadow = False
    
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.uv.smart_project(island_margin=0.2, stretch_to_bounds=False, use_aspect=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    # Move the new object to layer 2
    bpy.ops.object.move_to_layer(layers=(False, True, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False))
    
    # Remove all materials and create a blank one
    for m in range(len(newobj.material_slots)) :
        bpy.ops.object.material_slot_remove()
    
    blank_mat = bpy.data.materials.new('BLANK')
    newobj.data.materials.append(blank_mat)
    newobj.active_material.use_nodes = True
    
    # Add a texture for future baking
    bpy.data.images.new(name=newobj.name,width=1024,height=1024)
    bpy.data.images[newobj.name].use_fake_user = True
    
    # Reselect the initial objects and Make the initial selection the active one
    for obj in myselection:
        obj.select = True
    bpy.context.scene.objects.active = myactive
    newobj.select = False
    myactive.select = True
    
    ##
    '''
    myactive_name = myactive.name
    myselection = bpy.context.selected_objects
    
    # Create a copy of the object 
    newobj = myactive.copy()
    newobj.data = myactive.data.copy()
    newobj.name = myactive_name + "_BAKE"
    bpy.context.scene.objects.link(newobj)
    bpy.data.meshes.update()
    
    # Unwrap this new object
    myactive.select = False
    bpy.context.scene.objects.active = newobj
    
    # Make this object invisble to cyles
    newobj.cycles_visibility.camera = False
    newobj.cycles_visibility.diffuse = False
    newobj.cycles_visibility.glossy = False
    newobj.cycles_visibility.transmission = False
    newobj.cycles_visibility.scatter = False
    newobj.cycles_visibility.shadow = False
    
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.mesh.dissolve_limited()
    bpy.ops.uv.smart_project(island_margin=0.2, stretch_to_bounds=False, use_aspect=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    # Move the new object to layer 2
    bpy.ops.object.move_to_layer(layers=(False, True, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False))
    
    # Remove all materials and create a blank one
    for m in range(len(newobj.material_slots)) :
        bpy.ops.object.material_slot_remove()
    
    blank_mat = bpy.data.materials.new('BLANK')
    newobj.data.materials.append(blank_mat)
    newobj.active_material.use_nodes = True
    
    # Add a texture for future baking
    #bpy.data.images.new(name=newobj.name,width=1024,height=1024)
    #bpy.data.images[newobj.name].use_fake_user = True
    
    # Make the initial selection the active one
    bpy.context.scene.objects.active = myactive
    for obj in myselection:
        obj.select = True
    
    newobj.select = False
    myactive.select = True
    
class DuplicateBake(bpy.types.Operator):
    bl_idname = "my_operator.duplicate_bake"
    bl_label = "Duplicate Bake"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        join_board(context)
        duplicate_bake(context)
        return {"FINISHED"}

class DuplicateBakeAll(bpy.types.Operator):
    bl_idname = "my_operator.duplicate_bake_all"
    bl_label = "Duplicate Bake All"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        join_board_all(context)
        duplicate_bake(context)
        return {"FINISHED"}

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
