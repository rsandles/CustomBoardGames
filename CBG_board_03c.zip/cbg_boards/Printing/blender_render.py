import bpy

def texture_blender_render(context):
    
    myobj = bpy.context.active_object
    
    bpy.context.scene.render.engine = 'BLENDER_RENDER'
    
    # Delete all the previous materials
    for mat in myobj.data.materials :
        myobj.data.materials.pop()
    
    # Add a new material and assign the _BAKE texture to it
    mymat = bpy.data.materials.new(name="baked")
    myobj.active_material = mymat
    
    slot = mymat.texture_slots.add()
    slot.texture = bpy.data.textures.new("tex",'IMAGE')
    
    # Retrieve the latest created image
    img_list = [img for img in bpy.data.images if myobj.name in img.name]
    myimg = img_list[-1]
    slot.texture.image = myimg
    #slot.texture.image = bpy.data.images[myobj.name]
    
    # Make the new texture the active image for the object
    bpy.ops.object.mode_set(mode='EDIT')
    for area in bpy.context.screen.areas :
        if area.type == 'IMAGE_EDITOR' :
            area.spaces.active.image = myimg #
        else :
            bpy.context.area.type = 'IMAGE_EDITOR'
            if area.type == 'IMAGE_EDITOR' :
                area.spaces.active.image = myimg #
    
    bpy.context.area.type = 'VIEW_3D'
    bpy.ops.object.mode_set(mode='OBJECT')
    
class BlenderRender(bpy.types.Operator):
    bl_idname = "my_operator.blender_render"
    bl_label = "Blender Render"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "_BAKE" in obj.name

    def execute(self, context):
        texture_blender_render(context)
        bpy.ops.mesh.unfold()
        return {"FINISHED"}

class SetRenderEngine(bpy.types.Operator):
    bl_idname = "my_operator.set_render_engine"
    bl_label = "Set Render Engine"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return bpy.context.scene.render.engine == 'BLENDER_RENDER'

    def execute(self, context):
        bpy.context.scene.render.engine = 'CYCLES'
        for obj in bpy.context.visible_objects:
            if "_BAKE" in obj.name:
                obj.select = False
        bpy.context.scene.layers[0] = True
        bpy.context.scene.layers[1] = False
        return {"FINISHED"}
        

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
