import bpy

def bake_material(context):
    
    bpy.context.scene.render.engine = 'CYCLES'
    
    sc = bpy.data.scenes["Scene"]
    
    myactive = bpy.context.active_object
    myselection = context.selected_objects
    
    # Transform all instances into objects
    for obj in myselection:
        if obj.type != 'MESH':
            bpy.ops.object.duplicates_make_real()
    
    myselection = context.selected_objects
    
    # Remove all objects that cannot be baked
    for obj in myselection:
        if obj.type != 'MESH':
            obj.select = False
    
    mydupli = bpy.data.objects[myactive.name+"_BAKE"]
    
    # Check if duplicate has a cycles materials assigned, else create one
    # Happens when a baking already took place
    
    ##
    if mydupli.active_material.use_nodes == False:
        mydupli.active_material.use_nodes = True
    ##
    
    mymat = mydupli.active_material

    # Retrieve the baking quality
    bakequal=0
    if sc.bake_quality == '1k':
        bakequal = 1024
    elif sc.bake_quality == '2k':
        bakequal = 2048
    elif sc.bake_quality == '4k':
        bakequal = 4096
    
    # Create an image with that quality
    texture_img = bpy.data.images.new(
                                        name = myactive.name + "_BAKE",
                                        height = bakequal,
                                        width = bakequal
                                    )
    bake_texture = mymat.node_tree.nodes.new(type='ShaderNodeTexImage')
    bake_texture.image = texture_img
    
    baked_objects = [obj for obj in bpy.context.visible_objects if myactive.name in obj.name]
    print(baked_objects)
    
    for ob in baked_objects :
        ob.select = True
    
    bpy.context.scene.objects.active = mydupli
        
    bpy.context.scene.layers[0] = True
    bpy.context.scene.layers[1] = True
    
    # Set the height of the duplicate depending on wether there are furnitures to bake
    if sc.bake_furniture == True:
        mydupli.location.z = (sc.cell_size*2)
        bpy.context.scene.update()

    else:
        mydupli.location.z = 0
        bpy.context.scene.update()
    
    myactive.active_material.node_tree.nodes.active = bake_texture
    bpy.data.scenes["Scene"].render.bake.use_pass_direct = True
    bpy.data.scenes["Scene"].render.bake.use_pass_indirect = True
    
    
    
    print(bakequal)
     
    bpy.ops.object.bake(
                        type='COMBINED',
                        use_selected_to_active=True,
                        cage_extrusion=3,
                        use_clear=True
                        )
    
    for obj in myselection:
        obj.select = False
    bpy.context.scene.layers[0] = False
    bpy.context.scene.layers[1] = True
    mydupli.select = True
    bpy.context.scene.objects.active = mydupli

    
class BakeMaterial(bpy.types.Operator):
    bl_idname = "my_operator.bake_material"
    bl_label = "Bake Material"
    bl_description = ""
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and "Board" in obj.name and not "_BAKE" in obj.name

    def execute(self, context):
        bake_material(context)
        bpy.ops.my_operator.blender_render()
        return {"FINISHED"}
    
def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
